package be.krivi.plutus.android.network.retrofit;

/**
 * Created by Jan on 14/12/2015.
 */
public class Verify{






}
